# Getting Started with Create React App

This project realate to react CRUD

## How to start this project

    step 1: npm i
    step 2: json-server --watch db.json // http://localhost:3000
    step 3:  npm  // http://localhost:3001
