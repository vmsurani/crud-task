import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Loader from "../Common/Loader";
import "./User.css";

const CreateUser = () => {
  const navigate = useNavigate();
  const createUserApi = "http://localhost:3001/user"; // API endpoint to save user data
  const [error, setError] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [user, setUser] = useState({
    name: "",
    email: "",
    phone: "",
    dob: "",
    address: "",
  });
  const [highestId, setHighestId] = useState(0); // State to track highest ID

  useEffect(() => {
    // Fetch the highest ID from the server when component mounts
    const fetchHighestId = async () => {
      try {
        const response = await fetch(createUserApi);
        if (response.ok) {
          const data = await response.json();
          if (data.length > 0) {
            const maxId = Math.max(...data.map((user) => user.id));
            setHighestId(maxId);
          }
        } else {
          console.error("Failed to fetch users");
        }
      } catch (error) {
        console.error("Error fetching users:", error);
      }
    };

    fetchHighestId();
  }, [createUserApi]);

  const handelInput = (event) => {
    event.preventDefault();
    const { name, value } = event.target;
    setUser({ ...user, [name]: value });
  };

  const handelSubmit = async (event) => {
    event.preventDefault();
    try {
      setIsLoading(true);
      const newUser = { ...user, id: highestId + 1 }; // Increment the highest ID for the new user
      const response = await fetch(createUserApi, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(newUser),
      });

      if (response.ok) {
        console.log("Form submitted successfully!");
        setUser({
          name: "",
          email: "",
          phone: "",
          dob: "",
          address: "",
        });
        setHighestId((prevId) => prevId + 1); // Increment the highest ID
        navigate("/");
      } else {
        console.error("Form submission failed!");
      }
    } catch (error) {
      setError(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="user-form">
      <div className="heading">
        {isLoading && <Loader />}
   
        <p>User Form</p>
      </div>
      <form onSubmit={handelSubmit}>
        <div className="mb-3">
          <label htmlFor="name" className="form-label">
            Name
          </label>
          <input
            type="text"
            className="form-control"
            id="name"
            name="name"
            value={user.name}
            onChange={handelInput}
            required 
          />
        </div>
        <div className="mb-3 mt-3">
          <label htmlFor="email" className="form-label">
            Email
          </label>
          <input
            type="email"
            className="form-control"
            id="email"
            name="email"
            value={user.email}
            onChange={handelInput}
            required 
          />
        </div>
        <div className="mb-3">
          <label htmlFor="phone" className="form-label">
            Phone
          </label>
          <input
            type="text"
            className="form-control"
            id="phone"
            name="phone"
            value={user.phone}
            onChange={handelInput}
            required
          />
        </div>
        <div className="mb-3">
          <label htmlFor="dob" className="form-label">
            Date of Birth
          </label>
          <input
            type="date"
            className="form-control"
            id="dob"
            name="dob"
            value={user.dob}
            onChange={handelInput}
            required 
          />
        </div>
        <div className="mb-3">
          <label htmlFor="address" className="form-label">
            Address
          </label>
          <textarea
            type="address"
            className="form-control"
            id="address"
            name="address"
            value={user.address}
            onChange={handelInput}
            required 
          />
        </div>
        <button type="submit" className="btn btn-primary submit-btn">
          Submit
        </button>
      </form>
    </div>
  );
};

export default CreateUser;
