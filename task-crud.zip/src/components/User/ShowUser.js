import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import Loader from "../Common/Loader";
import "../User/User.css";

const ShowUser = () => {
  const showUserApi = "http://localhost:3001/user";

  const [user, setUser] = useState([]);
  const [filteredUser, setFilteredUser] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");

  const handelDelete = async (id) => {
    setIsLoading(true);
    try {
      const response = await fetch(`${showUserApi}/${id}`, {
        method: "DELETE",
      });
      if (!response.ok) {
        throw new Error("Failed to delete item");
      }
      setUser(user.filter((item) => item.id !== id));
      setFilteredUser(filteredUser.filter((item) => item.id !== id));
    } catch (error) {
      setError(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const getUsers = () => {
    axios
      .get(showUserApi)
      .then((res) => {
        setUser(res.data);
        setFilteredUser(res.data);
      })
      .catch((err) => {
        setError(err.message);
      });
  };

  useEffect(() => {
    getUsers();
  }, []);

  useEffect(() => {
    const filteredData = user.filter((user) => {
      return (
        user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        user.phone.includes(searchQuery) ||
        user.dob.includes(searchQuery)
      );
    });
    setFilteredUser(filteredData);
  }, [searchQuery, user]);

  const formatDate = (dateString) => {
    const parts = dateString.split("-");
    return `${parts[2]}/${parts[1]}/${parts[0]}`;
  };

  return (
    <div className="container mt-5">
      {isLoading && <Loader />}

      <div className="input-group mb-3">
    <input
      type="text"
      placeholder="Search by name, phone, or DOB"
      value={searchQuery}
      onChange={(e) => setSearchQuery(e.target.value)}
      className="form-control"
    />
    <button
      className="btn btn-primary"
      type="button"
      onClick={() => setSearchQuery("")}
    >
      Clear
    </button>
  </div>
      <div className="d-flex justify-content-end mb-4">
        <Link to="/create-user" className="btn btn-success">
          <i className="fa fa-plus" aria-hidden="true"></i> Add
        </Link>
      </div>

      <table className="table table-striped">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>DOB</th>
            <th>Address</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {filteredUser.map((user) => (
            <tr key={user.id}>
              <td>{user.id}</td>
              <td>{user.name}</td>
              <td>{user.email}</td>
              <td>{user.phone}</td>
              <td>{formatDate(user.dob)}</td>
              <td>{user.address}</td>
              <td>
                <Link
                  to={`/edit-user/${user.id}`}
                  className="btn btn-sm btn-info mr-2"
                >
                  Edit
                </Link>
                <button
                  className="btn btn-sm btn-danger"
                  onClick={() => handelDelete(user.id)}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ShowUser;
