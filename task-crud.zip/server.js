const express = require("express");
const jsonServer = require("json-server");
const fs = require("fs");

const app = express();

// Parse JSON request body
app.use(express.json());

// Load initial data
let data = JSON.parse(fs.readFileSync("db.json", "utf-8"));

// Middleware to intercept POST requests to /user endpoint and generate ID
app.post("/user", (req, res) => {
  const newUser = req.body;
  newUser.id = data.user.length + 1; // Increment the ID
  data.user.push(newUser); // Add the new user to the data array
  fs.writeFileSync("db.json", JSON.stringify(data, null, 2)); // Write data to db.json
  res.status(201).json(newUser); // Send response with the newly created user
});

// Start JSON Server
const server = jsonServer.create();
const router = jsonServer.router("db.json");
const middlewares = jsonServer.defaults();

server.use(middlewares);
server.use(router);
server.use(express.urlencoded({ extended: true }));
server.use(express.json());
server.listen(3001, () => {
  console.log("JSON Server is running");
});
